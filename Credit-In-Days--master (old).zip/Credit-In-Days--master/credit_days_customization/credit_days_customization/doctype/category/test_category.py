# Copyright (c) 2023, Akhilaminc and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestCategory(FrappeTestCase):
	pass

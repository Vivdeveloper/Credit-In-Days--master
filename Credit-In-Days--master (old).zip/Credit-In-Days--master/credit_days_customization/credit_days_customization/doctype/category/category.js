// Copyright (c) 2023, Akhilaminc and contributors
// For license information, please see license.txt

frappe.ui.form.on('Category', {
	// refresh: function(frm) {

	// }
});

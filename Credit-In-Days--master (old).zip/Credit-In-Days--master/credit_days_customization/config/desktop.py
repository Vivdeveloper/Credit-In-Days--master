from frappe import _

def get_data():
	return [
		{
			"module_name": "Credit Days Customization",
			"type": "module",
			"label": _("Credit Days Customization")
		}
	]
